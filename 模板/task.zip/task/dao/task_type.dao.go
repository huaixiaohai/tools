package dao

import (
	"context"

	"github.com/google/wire"

	"gorm.io/gorm"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao/model"

	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

var TaskTypeRepoSet = wire.NewSet(NewTaskTypeRepo)

func NewTaskTypeRepo() *TaskTypeRepo {
	return &TaskTypeRepo{}
}

type TaskTypeRepo struct {
}

func (a *TaskTypeRepo) Create(ctx context.Context, one *pb.TaskType) error {
	err := getSession(ctx).Model(&model.TaskType{}).Create(model.TaskTypeFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskTypeRepo) Update(ctx context.Context, one *pb.TaskType) error {
	err := getSession(ctx).Model(&model.TaskType{}).Where("id=?", one.Id).Updates(model.TaskTypeFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

//func (a *TaskTypeRepo) Delete(ctx context.Context, id uint64) error {
//	return getSession(ctx).Model(&model.TaskType{}).Where("id=?", id).Delete(&model.TaskType{}).Error
//}

func (a *TaskTypeRepo) Get(ctx context.Context, id uint64) (*pb.TaskType, error) {
	one := &model.TaskType{}
	err := getSession(ctx).Model(&model.TaskType{}).Where("id=?", id).First(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskTypeTo(one), nil
}

func (a *TaskTypeRepo) List(ctx context.Context) ([]*pb.TaskType, error) {
	data := make([]*model.TaskType, 0)
	err := getSession(ctx).Model(&model.TaskType{}).Find(&data).Error
	return model.TaskTypeListTo(data), err
}
