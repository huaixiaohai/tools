package dao

import (
	"context"

	"github.com/google/wire"

	"gorm.io/gorm"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao/model"

	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

var TaskNoteRepoSet = wire.NewSet(NewTaskNoteRepo)

func NewTaskNoteRepo() *TaskNoteRepo {
	return &TaskNoteRepo{}
}

type TaskNoteRepo struct {
}

func (a *TaskNoteRepo) Create(ctx context.Context, one *pb.TaskNote) error {
	err := getSession(ctx).Model(&model.TaskNote{}).Create(model.TaskNoteFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskNoteRepo) Update(ctx context.Context, one *pb.TaskNote) error {
	err := getSession(ctx).Model(&model.TaskNote{}).Where("id=?", one.Id).Updates(model.TaskNoteFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

//func (a *TaskNoteRepo) Delete(ctx context.Context, id uint64) error {
//	return getSession(ctx).Model(&model.TaskNote{}).Where("id=?", id).Delete(&model.TaskNote{}).Error
//}

func (a *TaskNoteRepo) Get(ctx context.Context, id uint64) (*pb.TaskNote, error) {
	one := &model.TaskNote{}
	err := getSession(ctx).Model(&model.TaskNote{}).Where("id=?", id).First(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskNoteTo(one), nil
}

func (a *TaskNoteRepo) List(ctx context.Context, req *pb.TaskNoteListReq) ([]*pb.TaskNote, error) {
	data := make([]*model.TaskNote, 0)
	err := getSession(ctx).Model(&model.TaskNote{}).Where("task_id=?", req.TaskId).Find(&data).Error
	return model.TaskNoteListTo(data), err
}
