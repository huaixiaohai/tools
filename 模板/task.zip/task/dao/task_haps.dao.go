package dao

import (
	"context"
	"time"

	"github.com/google/wire"

	"gorm.io/gorm"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao/model"

	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

var TaskHapsRepoSet = wire.NewSet(NewTaskHapsRepo)

func NewTaskHapsRepo() *TaskHapsRepo {
	return &TaskHapsRepo{}
}

type TaskHapsRepo struct {
}

func (a *TaskHapsRepo) Create(ctx context.Context, one *pb.TaskHaps) error {
	err := getSession(ctx).Model(&model.TaskHaps{}).Create(model.TaskHapsFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskHapsRepo) Update(ctx context.Context, one *pb.TaskHaps) error {
	err := getSession(ctx).Model(&model.TaskHaps{}).Where("id=?", one.Id).Updates(model.TaskHapsFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskHapsRepo) UpdateUnbindTime(ctx context.Context, id uint64, unbindTime int64) error {
	err := getSession(ctx).Model(&model.TaskHaps{}).Where("id=?", id).Updates(map[string]interface{}{"unbind_time": unbindTime, "updated_at": time.Now().Local()}).Error
	if err != nil {
		return err
	}
	return nil
}

//func (a *TaskHapsRepo) Delete(ctx context.Context, id uint64) error {
//	return getSession(ctx).Model(&model.TaskHaps{}).Where("id=?", id).Delete(&model.TaskHaps{}).Error
//}

func (a *TaskHapsRepo) Get(ctx context.Context, id uint64) (*pb.TaskHaps, error) {
	one := &model.TaskHaps{}
	err := getSession(ctx).Model(&model.TaskHaps{}).Where("id=?", id).First(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskHapsTo(one), nil
}

// GetLastByTaskID 获取改task_id绑定的taskHaps记录
func (a *TaskHapsRepo) GetLastByTaskID(ctx context.Context, taskID uint64) (*pb.TaskHaps, error) {
	one := &model.TaskHaps{}
	err := getSession(ctx).Model(&model.TaskHaps{}).Where("task_id=?", taskID).Last(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskHapsTo(one), nil
}

func (a *TaskHapsRepo) GetTaskIDsByApplyStatus(ctx context.Context, applyStatus pb.EHapsApplyStatus) ([]uint64, error) {
	ids := make([]uint64, 0)
	return ids, getSession(ctx).Model(&model.TaskHaps{}).Select("task_id").Where("apply_status = ?", applyStatus).Find(&ids).Error
}

type TaskHapsListReq struct {
	PageSize  int64
	PageIndex int64
	TaskID    uint64
}

func (a *TaskHapsRepo) List(ctx context.Context, req *TaskHapsListReq) ([]*pb.TaskHaps, error) {
	records := make([]*model.TaskHaps, 0)
	err := a.listReq(ctx, req).Find(&records).Error
	if err != nil {
		return nil, err
	}
	return model.TaskHapsListTo(records), nil
}

func (a *TaskHapsRepo) Count(ctx context.Context, req *TaskHapsListReq) (int64, error) {
	var count int64
	return count, a.listReq(ctx, req).Count(&count).Error
}

func (a *TaskHapsRepo) listReq(ctx context.Context, req *TaskHapsListReq) *gorm.DB {
	s := getSession(ctx).Model(&model.TaskHaps{})
	if req.TaskID > 0 {
		s.Where("task_id = ?", req.TaskID)
	}
	return s.Order("id desc").Limit(int(req.PageSize)).Offset(int((req.PageIndex - 1) * req.PageSize))
}
