package model

import (
	"encoding/json"

	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

type TaskHaps struct {
	Model
	TaskID     uint64 `gorm:"index"`
	HapsIDs    string
	BindTime   int64
	UnbindTime int64
	//ApplyStatus  pb.EHapsApplyStatus
	//IsRunScript  bool
	//IsTest       bool
	//VersionID    uint64
	//DpVersionID  uint64
	//TestFuncList string
	//TestBranch   string
}

func TaskHapsFrom(one *pb.TaskHaps) *TaskHaps {
	if one == nil {
		return nil
	}
	hapsIds, _ := json.Marshal(one.HapsIds)
	return &TaskHaps{
		Model: Model{
			ID: one.Id,
		},
		TaskID:     one.TaskId,
		HapsIDs:    string(hapsIds),
		BindTime:   one.BindTime,
		UnbindTime: one.UnbindTime,
	}
}

func TaskHapsTo(one *TaskHaps) *pb.TaskHaps {
	if one == nil {
		return nil
	}
	hapsIDs := make([]uint64, 0)
	_ = json.Unmarshal([]byte(one.HapsIDs), &hapsIDs)

	return &pb.TaskHaps{
		Id:         one.ID,
		TaskId:     one.TaskID,
		HapsIds:    hapsIDs,
		BindTime:   one.BindTime,
		UnbindTime: one.UnbindTime,
	}
}

func TaskHapsListTo(data []*TaskHaps) []*pb.TaskHaps {
	res := make([]*pb.TaskHaps, len(data))
	for k, v := range data {
		res[k] = TaskHapsTo(v)
	}
	return res
}
