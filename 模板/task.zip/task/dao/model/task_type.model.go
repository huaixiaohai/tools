package model

import "mgc-gitlab.mthreads.com/cloud-backend/task/pb"

type TaskType struct {
	Model
	Name string
}

func TaskTypeFrom(one *pb.TaskType) *TaskType {
	if one == nil {
		return nil
	}
	return &TaskType{
		Model: Model{
			ID: one.Id,
		},
		Name: one.Name,
	}
}

func TaskTypeTo(one *TaskType) *pb.TaskType {
	if one == nil {
		return nil
	}
	return &pb.TaskType{
		Id:   one.ID,
		Name: one.Name,
	}
}

func TaskTypeListTo(data []*TaskType) []*pb.TaskType {
	res := make([]*pb.TaskType, len(data))
	for k, v := range data {
		res[k] = TaskTypeTo(v)
	}
	return res
}
