package model

import "mgc-gitlab.mthreads.com/cloud-backend/task/pb"

type TaskNote struct {
	Model
	TaskID    uint64 `gorm:"index"`
	CreatorID uint64
	Note      string
}

func TaskNoteFrom(one *pb.TaskNote) *TaskNote {
	if one == nil {
		return nil
	}
	return &TaskNote{
		Model: Model{
			ID: one.Id,
		},
		Note:      one.Note,
		TaskID:    one.TaskId,
		CreatorID: one.CreatorId,
	}
}

func TaskNoteTo(one *TaskNote) *pb.TaskNote {
	if one == nil {
		return nil
	}
	return &pb.TaskNote{
		Id:        one.ID,
		Note:      one.Note,
		TaskId:    one.TaskID,
		CreatorId: one.CreatorID,
		CreatedAt: one.CreatedAt.Unix(),
	}
}

func TaskNoteListTo(data []*TaskNote) []*pb.TaskNote {
	res := make([]*pb.TaskNote, len(data))
	for k, v := range data {
		res[k] = TaskNoteTo(v)
	}
	return res
}
