package model

import (
	"encoding/json"
	"time"

	"gorm.io/gorm"
	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

type Task struct {
	Model
	Name        string
	Desc        string
	TypeIDs     string
	Status      pb.ETaskStatus
	CreatorID   uint64
	JiraUrl     string
	Priority    int64
	Progress    int64
	EstDuration int64
	ApplyStatus pb.EHapsApplyStatus
	ApplyTime   time.Time
	ApplyHapsID uint64

	IsTest       bool
	TestFuncList string
	TestBranch   string
	VersionID    uint64
	DPVersionID  uint64

	DeletedAt gorm.DeletedAt
}

func TaskFrom(one *pb.Task) *Task {
	if one == nil {
		return nil
	}

	funcList, _ := json.Marshal(one.TestFuncList)
	typeIDs, _ := json.Marshal(one.TypeIds)

	return &Task{
		Model: Model{
			ID:        one.Id,
			CreatedAt: time.Unix(one.CreatedAt, 0),
		},
		Name:        one.Name,
		Desc:        one.Desc,
		TypeIDs:     string(typeIDs),
		Status:      one.Status,
		CreatorID:   one.CreatorId,
		JiraUrl:     one.JiraUrl,
		Priority:    one.Priority,
		Progress:    one.Progress,
		EstDuration: one.EstDuration,
		ApplyStatus: one.ApplyStatus,
		ApplyHapsID: one.ApplyHapsId,

		IsTest:       one.IsTest,
		TestFuncList: string(funcList),
		TestBranch:   one.TestBranch,
		VersionID:    one.VersionId,
		DPVersionID:  one.DpVersionId,
	}
}

func TaskTo(one *Task) *pb.Task {
	if one == nil {
		return nil
	}

	funcList := make([]string, 0)
	_ = json.Unmarshal([]byte(one.TestFuncList), &funcList)

	typeIDs := make([]uint64, 0)
	_ = json.Unmarshal([]byte(one.TypeIDs), &typeIDs)

	return &pb.Task{
		Id:          one.ID,
		Name:        one.Name,
		Desc:        one.Desc,
		TypeIds:     typeIDs,
		Status:      one.Status,
		CreatorId:   one.CreatorID,
		CreatedAt:   one.CreatedAt.Unix(),
		JiraUrl:     one.JiraUrl,
		Priority:    one.Priority,
		Progress:    one.Progress,
		EstDuration: one.EstDuration,
		ApplyStatus: one.ApplyStatus,
		ApplyHapsId: one.ApplyHapsID,

		IsTest:       one.IsTest,
		TestFuncList: funcList,
		TestBranch:   one.TestBranch,
		VersionId:    one.VersionID,
		DpVersionId:  one.DPVersionID,
	}
}

func TaskListTo(data []*Task) []*pb.Task {
	res := make([]*pb.Task, len(data))
	for k, v := range data {
		res[k] = TaskTo(v)
	}
	return res
}
