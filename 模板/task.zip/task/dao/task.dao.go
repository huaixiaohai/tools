package dao

import (
	"context"
	"time"

	"github.com/google/wire"

	"gorm.io/gorm"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao/model"

	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

var TaskRepoSet = wire.NewSet(NewTaskRepo)

func NewTaskRepo() *TaskRepo {
	return &TaskRepo{}
}

type TaskRepo struct {
}

func (a *TaskRepo) Create(ctx context.Context, one *pb.Task) error {
	err := getSession(ctx).Model(&model.Task{}).Create(model.TaskFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskRepo) Update(ctx context.Context, one *pb.Task) error {
	err := getSession(ctx).Model(&model.Task{}).Where("id=?", one.Id).Updates(model.TaskFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskRepo) Save(ctx context.Context, one *pb.Task) error {
	err := getSession(ctx).Model(&model.Task{}).Where("id=?", one.Id).Save(model.TaskFrom(one)).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskRepo) Delete(ctx context.Context, id uint64) error {
	err := getSession(ctx).Model(&model.Task{}).Delete("id=?", id).Delete(&model.Task{}).Error
	if err != nil {
		return err
	}
	return nil
}

func (a *TaskRepo) Get(ctx context.Context, id uint64) (*pb.Task, error) {
	one := &model.Task{}
	err := getSession(ctx).Model(&model.Task{}).Where("id=?", id).First(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskTo(one), nil
}

type TaskListReq struct {
	PageSize    int64
	PageIndex   int64
	Status      pb.ETaskStatus
	CreatorID   uint64
	Name        string
	ApplyStatus pb.EHapsApplyStatus
}

// List 返回任务列表，按照优先级排序
func (a *TaskRepo) List(ctx context.Context, req *TaskListReq) ([]*pb.Task, error) {
	records := make([]*model.Task, 0)
	err := a.listReq(ctx, req).Find(&records).Error
	if err != nil {
		return nil, err
	}
	return model.TaskListTo(records), nil
}

func (a *TaskRepo) Count(ctx context.Context, req *TaskListReq) (int64, error) {
	var count int64
	return count, a.listReq(ctx, req).Count(&count).Error
}

func (a *TaskRepo) listReq(ctx context.Context, req *TaskListReq) *gorm.DB {
	s := getSession(ctx).Model(&model.Task{})
	if req.Status != pb.ETaskStatus_ETaskStatusNone {
		s.Where("status = ?", req.Status)
	}
	if req.CreatorID > 0 {
		s.Where("creator_id=?", req.CreatorID)
	}
	if req.Name != "" {
		s.Where("name like ?", "%"+req.Name+"%")
	}
	if req.ApplyStatus != pb.EHapsApplyStatus_EHapsApplyStatusNone {
		s.Where("apply_status=?", req.ApplyStatus)
	}
	return s.Order("priority desc, apply_time asc, id desc").Limit(int(req.PageSize)).Offset(int((req.PageIndex - 1) * req.PageSize))
}

func (a *TaskRepo) UpdateStatus(ctx context.Context, id uint64, status pb.ETaskStatus) error {
	return getSession(ctx).Model(&model.Task{}).Where("id=?", id).Updates(map[string]interface{}{"status": status, "updated_at": time.Now().Local()}).Error
}

func (a *TaskRepo) UpdateApplyStatus(ctx context.Context, id uint64, applyStatus pb.EHapsApplyStatus) error {
	return getSession(ctx).Model(&model.Task{}).Where("id=?", id).Updates(map[string]interface{}{"apply_status": applyStatus, "apply_time": time.Now().Local(), "updated_at": time.Now().Local()}).Error
}

func (a *TaskRepo) UpdatePriority(ctx context.Context, id uint64, priority int64) error {
	return getSession(ctx).Model(&model.Task{}).Where("id=?", id).Updates(map[string]interface{}{"priority": priority, "updated_at": time.Now().Local()}).Error
}

func (a *TaskRepo) UpdateProgress(ctx context.Context, id uint64, progress int64) error {
	return getSession(ctx).Model(&model.Task{}).Where("id=?", id).Updates(map[string]interface{}{"progress": progress, "updated_at": time.Now().Local()}).Error
}

// GetHighestPriorityTask 获取最高优先级的task
func (a *TaskRepo) GetHighestPriorityTask(ctx context.Context, typeIDs []uint64, applyStatus pb.EHapsApplyStatus) (*pb.Task, error) {
	one := &model.Task{}
	err := getSession(ctx).Model(&model.Task{}).Where("type_id in ? and apply_status = ?", typeIDs, applyStatus).Order("priority desc, updated_at asc").First(one).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return model.TaskTo(one), nil
}

// GetApplyingTask 获取申请中的任务，按照优先级排序
func (a *TaskRepo) GetApplyingTask(ctx context.Context) ([]*pb.Task, error) {
	data := make([]*model.Task, 0)
	err := getSession(ctx).Model(&model.Task{}).Where("apply_status=?", pb.EHapsApplyStatus_EHapsApplyStatusApplying).Order("priority desc, apply_time asc").Find(&data).Error
	if err != nil {
		return nil, err
	}
	return model.TaskListTo(data), nil
}
