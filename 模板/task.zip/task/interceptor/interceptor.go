package interceptor

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime"

	errors "mgc-gitlab.mthreads.com/cloud-backend/task/error"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/log"

	"google.golang.org/grpc"
)

//TODO: 记一次请求的时间
func LoggingInterceptor(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (resp interface{}, err error) {
	// 进入打印日志，确认入参
	buf, _ := json.Marshal(req)
	log.Info(fmt.Sprintf("[grpc-request] %s, request: %s", info.FullMethod, string(buf)))

	resp, err = handler(ctx, req)

	// 处理完打印日志，包括出参和error
	if err != nil {
		log.Error(fmt.Sprintf("[grpc-request] %s, err: %s", info.FullMethod, err.Error()))
		return
	}
	buf, _ = json.Marshal(resp)
	log.Info(fmt.Sprintf("[grpc-response] %s, response: %s", info.FullMethod, string(buf)))
	return
}

func ServerRecoveryInterceptor(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (resp interface{}, err error) {
	defer func() {
		if e := recover(); e != nil {
			const size = 64 << 10
			stacktrace := make([]byte, size)
			stacktrace = stacktrace[:runtime.Stack(stacktrace, false)]
			// error及堆栈进行日志打印
			log.Error(e, string(stacktrace))

			err = errors.SystemException
		}
	}()

	return handler(ctx, req)
}
