package service

import (
	"context"

	"github.com/google/wire"
	"mgc-gitlab.mthreads.com/cloud-backend/lib/snowflake"
	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"
)

var TaskNoteSvcSet = wire.NewSet(NewTaskNoteSvc)

func NewTaskNoteSvc(taskNoteRepo *dao.TaskNoteRepo) *TaskNoteSvc {
	return &TaskNoteSvc{
		taskNoteRepo: taskNoteRepo,
	}
}

type TaskNoteSvc struct {
	*pb.UnimplementedTaskNoteSvcServer
	taskNoteRepo *dao.TaskNoteRepo
}

func (a *TaskNoteSvc) Create(ctx context.Context, taskNote *pb.TaskNote) (*pb.ID, error) {
	taskNote.Id = snowflake.MustID()
	return &pb.ID{Id: taskNote.Id}, a.taskNoteRepo.Create(ctx, taskNote)
}

func (a *TaskNoteSvc) Update(ctx context.Context, taskNote *pb.TaskNote) (*pb.Empty, error) {
	return &pb.Empty{}, a.taskNoteRepo.Update(ctx, taskNote)
}

func (a *TaskNoteSvc) List(ctx context.Context, req *pb.TaskNoteListReq) (*pb.TaskNoteListResp, error) {
	notes, err := a.taskNoteRepo.List(ctx, req)
	if err != nil {
		return nil, err
	}
	return &pb.TaskNoteListResp{List: notes}, nil
}

func (a *TaskNoteSvc) Get(ctx context.Context, req *pb.ID) (*pb.TaskNote, error) {
	return a.taskNoteRepo.Get(ctx, req.Id)
}
