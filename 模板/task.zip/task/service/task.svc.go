package service

import (
	"bytes"
	"context"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/redis"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/log"

	"mgc-gitlab.mthreads.com/cloud-backend/task/config"
	errors "mgc-gitlab.mthreads.com/cloud-backend/task/error"

	"github.com/google/wire"

	hapspb "mgc-gitlab.mthreads.com/cloud-backend/haps/pb"
	"mgc-gitlab.mthreads.com/cloud-backend/lib/snowflake"
	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"
	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
	userpb "mgc-gitlab.mthreads.com/cloud-backend/user/pb"
)

const (
	testTaskDuration  int64 = 12 * 3600
	debugTaskDuration int64 = 4 * 3600

	redisStopScheduleKey = "redis_stop_task_schedule_key"
	redisScheduleLockKey = "redis_task_schedule_lock_key"
	redisScheduleLockTTl = 30 * time.Second
)

var TaskSvcSet = wire.NewSet(NewTaskSvc)

func NewTaskSvc(
	taskRepo *dao.TaskRepo,
	taskHapsRepo *dao.TaskHapsRepo,

	hapsSvc *HapsSvc,
	userSvc *UserSvc,
) *TaskSvc {
	svc := &TaskSvc{
		taskRepo:     taskRepo,
		taskHapsRepo: taskHapsRepo,

		hapsSvc: hapsSvc,
		userSvc: userSvc,

		redisLocker: redis.NewLocker(),
	}

	svc.init()

	return svc
}

type TaskSvc struct {
	*pb.UnimplementedTaskSvcServer
	taskRepo     *dao.TaskRepo
	taskHapsRepo *dao.TaskHapsRepo

	hapsSvc *HapsSvc
	userSvc *UserSvc

	redisLocker *redis.Locker
}

func (a *TaskSvc) init() {
	go a.schedule()
}

func (a *TaskSvc) Create(ctx context.Context, task *pb.Task) (*pb.ID, error) {
	task.Id = snowflake.MustID()
	task.Status = pb.ETaskStatus_ETaskStatusWait
	task.ApplyStatus = pb.EHapsApplyStatus_EHapsApplyStatusWait
	task.CreatedAt = time.Now().Unix()
	return &pb.ID{Id: task.Id}, a.taskRepo.Create(ctx, task)
}

func (a *TaskSvc) Get(ctx context.Context, req *pb.ID) (*pb.Task, error) {
	task, err := a.taskRepo.Get(ctx, req.Id)
	if err != nil {
		return nil, err
	}
	if task == nil {
		return nil, errors.ErrTaskNotFound
	}
	if task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
		task.TaskHaps, err = a.GetTaskHapsByTaskID(ctx, req)
		if err != nil {
			return nil, err
		}
	}
	return task, nil
}

func (a *TaskSvc) List(ctx context.Context, req *pb.TaskListReq) (*pb.TaskListResp, error) {
	daoReq := &dao.TaskListReq{
		PageSize:    req.PageSize,
		PageIndex:   req.PageIndex,
		Status:      req.Status,
		CreatorID:   req.CreatorId,
		Name:        req.Name,
		ApplyStatus: req.ApplyStatus,
	}
	data, err := a.taskRepo.List(ctx, daoReq)
	if err != nil {
		return nil, err
	}

	daoReq.PageIndex, daoReq.PageSize = 0, 0
	var total int64
	total, err = a.taskRepo.Count(ctx, daoReq)
	if err != nil {
		return nil, err
	}

	if len(data) > 0 { // 可优化，一次性查询
		for _, v := range data {
			if v.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
				v.TaskHaps, _ = a.GetTaskHapsByTaskID(ctx, &pb.ID{Id: v.Id})
			}
		}
	}

	return &pb.TaskListResp{
		PageSize:  req.PageSize,
		PageIndex: req.PageIndex,
		Total:     total,
		List:      data,
	}, nil
}

func (a *TaskSvc) Update(ctx context.Context, req *pb.Task) (*pb.Empty, error) {
	task, err := a.taskRepo.Get(ctx, req.Id)
	if err != nil {
		return nil, err
	}
	if task == nil {
		return nil, errors.ErrTaskNotFound
	}

	task.Name = req.Name
	task.JiraUrl = req.JiraUrl
	task.EstDuration = req.EstDuration
	task.TypeIds = req.TypeIds
	task.ApplyHapsId = req.ApplyHapsId
	task.Desc = req.Desc
	task.IsTest = req.IsTest
	if task.IsTest {
		task.TestFuncList = req.TestFuncList
		task.TestBranch = req.TestBranch
		task.VersionId = req.VersionId
		task.DpVersionId = req.DpVersionId
	}
	return &pb.Empty{}, a.taskRepo.Save(ctx, task)
}

func (a *TaskSvc) Delete(ctx context.Context, req *pb.DeleteTaskReq) (*pb.Empty, error) {
	task, err := a.Get(ctx, &pb.ID{Id: req.Id})
	if err != nil {
		return nil, err
	}
	if task.CreatorId != req.UserId {
		return nil, errors.New500("不允许删除别人的任务")
	}

	return &pb.Empty{}, transaction(ctx, func(ctx context.Context) error {
		err = a.unbindHaps(ctx, task.Id)
		if err != nil {
			return err
		}

		err = a.taskRepo.Delete(ctx, task.Id)
		if err != nil {
			return err
		}
		return nil
	})
}

func (a *TaskSvc) UpdateStatus(ctx context.Context, req *pb.UpdateTaskStatusReq) (*pb.Empty, error) {
	var err error
	idReq := &pb.ID{Id: req.Id}
	switch req.Status {
	case pb.ETaskStatus_ETaskStatusNone:
		err = errors.New500("不能更新为该状态")
	case pb.ETaskStatus_ETaskStatusWait:
		_, err = a.wait(ctx, idReq)
	case pb.ETaskStatus_ETaskStatusRun:
		_, err = a.run(ctx, idReq)
	case pb.ETaskStatus_ETaskStatusSuspended:
		_, err = a.suspended(ctx, idReq)
	case pb.ETaskStatus_ETaskStatusFinish:
		_, err = a.finish(ctx, idReq)
	}
	if err != nil {
		log.Error(err)
	}
	return &pb.Empty{}, err
}

// UpdatePriority 更新优先级
func (a *TaskSvc) UpdatePriority(ctx context.Context, req *pb.UpdateTaskPriorityReq) (*pb.Empty, error) {
	return &pb.Empty{}, a.taskRepo.UpdatePriority(ctx, req.Id, req.Priority)
}

// UpdateProgress 更新进度
func (a *TaskSvc) UpdateProgress(ctx context.Context, req *pb.UpdateTaskProgressReq) (*pb.Empty, error) {
	return &pb.Empty{}, a.taskRepo.UpdateProgress(ctx, req.Id, req.Progress)
}

// ApplyHaps 申请haps：该方法只会更新记录的申请状态（生产者：生产一条申请记录， 消费者：haps服务作为消费者，会在该task服务下获取可执行任务优先级最高的任务进行bind，调用BindHaps方法）
func (a *TaskSvc) ApplyHaps(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	task, err := a.Get(ctx, req)
	if err != nil {
		return &pb.Empty{}, err
	}
	if task.Status != pb.ETaskStatus_ETaskStatusWait && task.Status != pb.ETaskStatus_ETaskStatusSuspended {
		return nil, errors.New500("当前状态下无法申请设备")
	}
	if task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplying || task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
		return &pb.Empty{}, nil
	}
	return &pb.Empty{}, a.taskRepo.UpdateApplyStatus(ctx, req.Id, pb.EHapsApplyStatus_EHapsApplyStatusApplying)
}

func (a *TaskSvc) CancelApplyHaps(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	task, err := a.Get(ctx, req)
	if err != nil {
		return &pb.Empty{}, err
	}
	if task.ApplyStatus != pb.EHapsApplyStatus_EHapsApplyStatusApplying {
		return &pb.Empty{}, nil
	}
	return &pb.Empty{}, a.taskRepo.UpdateApplyStatus(ctx, req.Id, pb.EHapsApplyStatus_EHapsApplyStatusWait)
}

func (a *TaskSvc) GetTaskHapsByTaskID(ctx context.Context, req *pb.ID) (*pb.TaskHaps, error) {
	one, err := a.taskHapsRepo.GetLastByTaskID(ctx, req.Id)
	if err != nil {
		return nil, err
	}
	if one == nil {
		return nil, errors.NotFound
	}
	return one, nil
}

func (a *TaskSvc) HapsUseDuration(ctx context.Context, req *pb.ID) (*pb.HapsUseDurationResp, error) {
	list, err := a.taskHapsRepo.List(ctx, &dao.TaskHapsListReq{
		TaskID: req.Id,
	})
	if err != nil {
		return nil, err
	}

	var duration int64
	for _, v := range list {
		if v.UnbindTime < v.BindTime {
			v.UnbindTime = time.Now().Local().Unix()
		}
		x := v.UnbindTime - v.BindTime
		if x > 0 {
			duration += x
		}
	}
	return &pb.HapsUseDurationResp{
		TaskId:      req.Id,
		UseDuration: duration,
	}, nil
}

func (a *TaskSvc) ScheduleStatus(ctx context.Context, req *pb.Empty) (*pb.Bool, error) {
	_, isStop, err := redis.Get(ctx, redisStopScheduleKey)
	if err != nil {
		log.Error(err)
		return nil, err
	}
	return &pb.Bool{B: !isStop}, nil
}

func (a *TaskSvc) SetScheduleStatus(ctx context.Context, req *pb.Bool) (*pb.Empty, error) {
	var err error
	if req.B {
		err = redis.Del(ctx, redisStopScheduleKey)
	} else {
		err = redis.Set(ctx, redisStopScheduleKey, "true", redis.KeepTTL)
	}
	if err != nil {
		log.Error(err)
		return nil, err
	}
	return &pb.Empty{}, nil
}

func (a *TaskSvc) CountStat(ctx context.Context, req *pb.Empty) (*pb.TaskCountStatResp, error) {
	resp := &pb.TaskCountStatResp{}
	var err error
	resp.Total, err = a.taskRepo.Count(ctx, &dao.TaskListReq{})
	if err != nil {
		return nil, err
	}
	resp.Finished, err = a.taskRepo.Count(ctx, &dao.TaskListReq{
		Status: pb.ETaskStatus_ETaskStatusFinish,
	})
	if err != nil {
		return nil, err
	}
	resp.Run, err = a.taskRepo.Count(ctx, &dao.TaskListReq{
		Status: pb.ETaskStatus_ETaskStatusRun,
	})
	if err != nil {
		return nil, err
	}
	resp.Applying, err = a.taskRepo.Count(ctx, &dao.TaskListReq{
		ApplyStatus: pb.EHapsApplyStatus_EHapsApplyStatusApplying,
	})
	if err != nil {
		return nil, err
	}
	return resp, err
}

func (a *TaskSvc) wait(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	return nil, errors.New500("请切换到挂起状态")
}

// 运行任务
func (a *TaskSvc) run(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	task, err := a.Get(ctx, req)
	if err != nil {
		return nil, err
	}
	if task.Status == pb.ETaskStatus_ETaskStatusRun {
		return &pb.Empty{}, nil
	}
	//if task.Status == pb.ETaskStatus_ETaskStatusFinish {
	//	return nil, errors.New500("任务已经完成")
	//}
	//if task.Status != pb.ETaskStatus_ETaskStatusWait && task.Status != pb.ETaskStatus_ETaskStatusSuspended {
	//	return nil, errors.New500(fmt.Sprintf("当前状态 <%s> 不允许切换到 <%s> 状态", pb.ETaskStatus_name[int32(task.Status)], pb.ETaskStatus_name[int32(pb.ETaskStatus_ETaskStatusRun)]))
	//}
	if task.ApplyStatus != pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
		return &pb.Empty{}, errors.New500("还未申请到haps")
	}
	err = a.taskRepo.UpdateStatus(ctx, task.Id, pb.ETaskStatus_ETaskStatusRun)
	if err != nil {
		log.Error(err)
		return nil, err
	}
	return &pb.Empty{}, nil
}

// 挂起任务,挂起后会自动解绑haps
func (a *TaskSvc) suspended(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	task, err := a.Get(ctx, req)
	if err != nil {
		return nil, err
	}
	if task.Status == pb.ETaskStatus_ETaskStatusSuspended {
		return &pb.Empty{}, nil
	}
	//if task.Status == pb.ETaskStatus_ETaskStatusFinish {
	//	return nil, errors.New500("任务已经完成")
	//}
	//if task.Status != pb.ETaskStatus_ETaskStatusRun {
	//	return nil, errors.New500(fmt.Sprintf("当前状态 <%s> 不允许切换到 <%s> 状态", pb.ETaskStatus_name[int32(task.Status)], pb.ETaskStatus_name[int32(pb.ETaskStatus_ETaskStatusSuspended)]))
	//}
	err = transaction(ctx, func(ctx context.Context) error {
		//if task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
		err = a.unbindHaps(ctx, req.Id)
		if err != nil {
			return err
		}
		//}
		err = a.taskRepo.UpdateStatus(ctx, task.Id, pb.ETaskStatus_ETaskStatusSuspended)
		if err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return &pb.Empty{}, nil
}

// 完成任务
func (a *TaskSvc) finish(ctx context.Context, req *pb.ID) (*pb.Empty, error) {
	task, err := a.Get(ctx, req)
	if err != nil {
		return nil, err
	}
	if task.Status == pb.ETaskStatus_ETaskStatusFinish {
		return &pb.Empty{}, nil
	}

	err = transaction(ctx, func(ctx context.Context) error {
		err = a.unbindHaps(ctx, req.Id)
		if err != nil {
			return err
		}

		err = a.taskRepo.UpdateStatus(ctx, task.Id, pb.ETaskStatus_ETaskStatusFinish)
		if err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return &pb.Empty{}, nil
}

// 解绑haps，如果没有绑定或者申请中的调用该方法也没问题
func (a *TaskSvc) unbindHaps(ctx context.Context, id uint64) error {
	task, err := a.Get(ctx, &pb.ID{Id: id})
	if err != nil {
		return err
	}

	if task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplying {
		err = a.taskRepo.UpdateApplyStatus(ctx, id, pb.EHapsApplyStatus_EHapsApplyStatusWait)
		if err != nil {
			return err
		}
		return nil
	}

	if task.ApplyStatus == pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess {
		err = transaction(ctx, func(ctx context.Context) error {
			err = a.taskHapsRepo.UpdateUnbindTime(ctx, task.TaskHaps.Id, time.Now().Local().Unix())
			if err != nil {
				return err
			}

			err = a.taskRepo.UpdateApplyStatus(ctx, id, pb.EHapsApplyStatus_EHapsApplyStatusWait)
			if err != nil {
				return err
			}

			for _, hapsID := range task.TaskHaps.HapsIds {
				_, err = a.hapsSvc.Free(ctx, &hapspb.FreeHapsReq{
					Id:     hapsID,
					UserId: task.CreatorId,
				})
				if err != nil {
					log.Error(err)
					return err
				}
			}

			return nil
		})
		if err != nil {
			return err
		}
		return nil
	}
	return nil
}

// 轮询绑定haps (调度策略)
func (a *TaskSvc) pollBindHaps(ctx context.Context) {
	resp, err := a.hapsSvc.CanUseList(ctx, &hapspb.Empty{})
	if err != nil {
		log.Error(err)
		return
	}

	if len(resp.List) <= 0 {
		return
	}

	hapsList := make([]*hapspb.Haps, len(resp.List))
	hapsM := make(map[string]*hapspb.Haps)
	hapsIDM := make(map[uint64]*hapspb.Haps)
	for k, v := range resp.List {
		hapsList[k] = v
		hapsM[v.Name] = v
		hapsIDM[v.Id] = v
	}

	tasks, err := a.taskRepo.GetApplyingTask(ctx)
	if err != nil {
		log.Error(err)
		return
	}

	if len(tasks) <= 0 {
		return
	}

	contain := func(ids1 []uint64, ids2 []uint64) bool {
		if len(ids2) <= 0 {
			return true
		}
		m := make(map[uint64]bool)
		for _, id := range ids1 {
			m[id] = true
		}

		has := true
		for _, id := range ids2 {
			_, has = m[id]
			if !has {
				break
			}
		}
		return has
	}

	for _, task := range tasks {

		success := false
		hapsIDs := make([]uint64, 0)
		if task.ApplyHapsId != 0 {
			haps, has := hapsIDM[task.ApplyHapsId]
			if has {
				success = true
				hapsIDs = []uint64{haps.Id}
			}
		} else {
			// 判断MT_LINK的特殊逻辑
			bMTLink := func() bool {
				const GpuID = 8
				const MtLinkID = 9

				var bLink bool
				var bGPU bool
				for _, id := range task.TypeIds {
					if id == MtLinkID {
						bLink = true
					}
					if id == GpuID {
						bGPU = true
					}
				}
				if !bLink { // 如果不是mtlink 返回false
					return false
				}
				var v1 *hapspb.Haps
				var v2 *hapspb.Haps
				if bLink && bGPU {
					v1 = hapsM["MGC-04"]
					v2 = hapsM["MGC-13"]
				} else if bLink && !bGPU {
					v1 = hapsM["MGC-02"]
					v2 = hapsM["MGC-03"]
					if v1 == nil || v2 == nil {
						v1 = hapsM["MGC-09"]
						v2 = hapsM["MGC-10"]
					}
				}
				if v1 != nil && v2 != nil {
					success = true
					hapsIDs = []uint64{v1.Id, v2.Id}
				}
				return true
			}()

			if !bMTLink {
				for _, haps := range resp.List {
					if contain(haps.TaskTypeIds, task.TypeIds) {
						hapsIDs = []uint64{haps.Id}
						success = true
						break
					}
				}
			}
		}

		if !success {
			continue
		}
		err = transaction(ctx, func(ctx context.Context) error {
			taskHaps := &pb.TaskHaps{
				Id:       snowflake.MustID(),
				TaskId:   task.Id,
				HapsIds:  hapsIDs,
				BindTime: time.Now().Unix(),
			}
			err = a.taskHapsRepo.Create(ctx, taskHaps)
			if err != nil {
				log.Error(err)
				return err
			}

			applyDuration := debugTaskDuration

			if task.IsTest { //如果是测试任务则直接更新为运行中任务
				err = a.taskRepo.UpdateStatus(ctx, task.Id, pb.ETaskStatus_ETaskStatusRun)
				applyDuration = testTaskDuration
			}

			err = a.taskRepo.UpdateApplyStatus(ctx, task.Id, pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess)
			if err != nil {
				log.Error(err)
				return err
			}

			for _, id := range hapsIDs {
				_, err = a.hapsSvc.Use(ctx, &hapspb.UseHapsReq{
					Id:            id,
					TaskId:        task.Id,
					BindId:        taskHaps.Id,
					TaskDesc:      task.Name,
					IsTest:        task.IsTest,
					TestFuncList:  task.TestFuncList,
					TestBranch:    task.TestBranch,
					VersionId:     task.VersionId,
					DpVersionId:   task.DpVersionId,
					UserId:        task.CreatorId,
					ApplyDuration: applyDuration,
				})
				if err != nil {
					log.Error(err)
					return err
				}
			}

			return nil
		})
		if err != nil {
			log.Error(err)
			return
		}
		a.pushUseDingTalkMsg(ctx, task)
		return
	}
}

// 轮询解绑haps
func (a *TaskSvc) pollUnbindHaps(ctx context.Context) {
	tasks, err := a.taskRepo.List(ctx, &dao.TaskListReq{
		ApplyStatus: pb.EHapsApplyStatus_EHapsApplyStatusApplySuccess,
	})
	if err != nil {
		log.Error(err)
		return
	}

	for _, task := range tasks {
		taskHaps, err := a.taskHapsRepo.GetLastByTaskID(ctx, task.Id)
		if err != nil {
			log.Error(err)
			continue
		}
		if taskHaps == nil {
			continue
		}
		if task.Status != pb.ETaskStatus_ETaskStatusRun {
			if time.Now().Local().Unix()-taskHaps.BindTime >= 15*60 { // 大于十五分钟
				err = a.unbindHaps(ctx, task.Id)
				if err != nil {
					log.Error(err)
					continue
				}
			}
		} else {
			if task.IsTest {
				if time.Now().Local().Unix()-taskHaps.BindTime >= testTaskDuration {
					_, err = a.suspended(ctx, &pb.ID{Id: task.Id})
					if err != nil {
						log.Error(err)
					}
				}
			} else {
				if time.Now().Local().Unix()-taskHaps.BindTime >= debugTaskDuration {
					_, err = a.suspended(ctx, &pb.ID{Id: task.Id})
					if err != nil {
						log.Error(err)
					}
				}
			}
		}
	}

}

func (a *TaskSvc) pushUseDingTalkMsg(ctx context.Context, task *pb.Task) {
	user, err := a.userSvc.Get(ctx, &userpb.UserID{Id: task.CreatorId})
	if err != nil {
		log.Error(err)
		return
	}
	msg := fmt.Sprintf(`{
    "msgtype": "actionCard",
    "actionCard": {
        "title": "@%s", 
        "text": "%s 设备已经申请成功", 
        "btnOrientation": "0", 
        "btns": [
            {
                "title": "跳转任务管理详情", 
                "actionURL": "dingtalk://dingtalkclient/page/link?pc_slide=false&url=%s"
            }
        ]
    }
}`, user.RealName, user.RealName, config.C.WebAddr+"/taskdetail%3Fid%3D"+strconv.FormatUint(task.Id, 10))

	r := bytes.NewBuffer([]byte(msg))
	_, err = http.Post(config.C.DingTalkHook, "application/json", r)
	if err != nil {
		log.Error(err)
		return
	}
}

// 调度(这里使用轮询方式，进行绑定与解绑，同时做了多实例的分布式互斥锁)
func (a *TaskSvc) schedule() {
	ctx := context.Background()
	for true {
		// 五秒轮询一次
		time.Sleep(5 * time.Second)

		// 查询全局调度状态，看是否禁止调度
		_, isStop, err := redis.Get(ctx, redisStopScheduleKey)
		if err != nil {
			log.Error(err)
		}
		if isStop {
			continue
		}

		// 如果没有禁止调度，则获取调度锁，防止多实例的并发问题
		err = a.redisLocker.Lock(redisScheduleLockKey, redisScheduleLockTTl)
		if err != nil {
			log.Error(err)
			continue
		}

		// 获取到锁，则开始调度
		// 先进行 <任务-haps> 解绑操作，再进行 <任务-haps> 绑定操作
		a.pollUnbindHaps(ctx)
		a.pollBindHaps(ctx)

		// 一次轮询调度结束，释放锁
		err = a.redisLocker.Unlock()
		if err != nil {
			log.Error(err)
		}
	}
}
