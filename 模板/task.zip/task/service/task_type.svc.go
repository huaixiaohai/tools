package service

import (
	"context"

	errors "mgc-gitlab.mthreads.com/cloud-backend/task/error"

	"github.com/google/wire"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/snowflake"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"
	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
)

var TaskTypeSvcSet = wire.NewSet(NewTaskTypeSvc)

func NewTaskTypeSvc(taskTypeRepo *dao.TaskTypeRepo) *TaskTypeSvc {
	return &TaskTypeSvc{
		taskTypeRepo: taskTypeRepo,
	}
}

type TaskTypeSvc struct {
	*pb.UnimplementedTaskTypeSvcServer
	taskTypeRepo *dao.TaskTypeRepo
}

func (a *TaskTypeSvc) Create(ctx context.Context, taskType *pb.TaskType) (*pb.ID, error) {
	taskType.Id = snowflake.MustID()
	return &pb.ID{Id: taskType.Id}, a.taskTypeRepo.Create(ctx, taskType)
}

func (a *TaskTypeSvc) Update(ctx context.Context, taskType *pb.TaskType) (*pb.Empty, error) {
	return &pb.Empty{}, a.taskTypeRepo.Update(ctx, taskType)
}

func (a *TaskTypeSvc) List(ctx context.Context, req *pb.TaskTypeListReq) (*pb.TaskTypeListResp, error) {
	types, err := a.taskTypeRepo.List(ctx)
	if err != nil {
		return nil, err
	}
	return &pb.TaskTypeListResp{List: types}, nil
}

func (a *TaskTypeSvc) Get(ctx context.Context, req *pb.ID) (*pb.TaskType, error) {
	res, err := a.taskTypeRepo.Get(ctx, req.Id)
	if err != nil {
		return nil, err
	}
	if res == nil {
		return nil, errors.NotFound
	}
	return res, nil
}
