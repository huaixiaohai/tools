package service

import (
	"github.com/google/wire"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"mgc-gitlab.mthreads.com/cloud-backend/haps/pb"
	"mgc-gitlab.mthreads.com/cloud-backend/task/config"
)

var HapsSvcSet = wire.NewSet(NewHapsSvc)

var cc *grpc.ClientConn

func init() {
	conf := config.C.GRPCAddress
	var err error
	cc, err = grpc.Dial(conf.Haps, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		panic("")
	}
}

func NewHapsSvc() *HapsSvc {
	return &HapsSvc{
		pb.NewHapsSvcClient(cc),
	}
}

type HapsSvc struct {
	pb.HapsSvcClient
}
