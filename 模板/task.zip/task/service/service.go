package service

import (
	"github.com/google/wire"
	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"
)

var Set = wire.NewSet(
	TaskSvcSet,
	TaskTypeSvcSet,
	TaskNoteSvcSet,
	//HapsTaskSvcSet,

	HapsSvcSet,
	UserSvcSet,
)

var transaction = dao.Transaction

//var (
//	taskSvc     *TaskSvc
//	taskNoteSvc *TaskNoteSvc
//	taskTypeSvc *TaskTypeSvc
//	hapsTaskSvc *HapsTaskSvc
//)
