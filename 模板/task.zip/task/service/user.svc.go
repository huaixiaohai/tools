package service

import (
	"github.com/google/wire"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"mgc-gitlab.mthreads.com/cloud-backend/task/config"
	"mgc-gitlab.mthreads.com/cloud-backend/user/pb"
)

var UserSvcSet = wire.NewSet(NewUserSvc)

var userCC *grpc.ClientConn

func init() {
	conf := config.C.GRPCAddress
	var err error
	userCC, err = grpc.Dial(conf.User, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		panic("")
	}
}

func NewUserSvc() *UserSvc {
	return &UserSvc{
		pb.NewUserSvcClient(userCC),
	}
}

type UserSvc struct {
	pb.UserSvcClient
}
