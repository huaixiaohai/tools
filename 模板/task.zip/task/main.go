package main

import (
	"fmt"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/redis"

	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/log"
	"mgc-gitlab.mthreads.com/cloud-backend/task/config"
)

func init() {
	log.Init(&log.Cfg{
		Level:    config.C.Log.Level,
		Output:   config.C.Log.Output,
		FilePath: config.C.Log.FilePath,
	})
	err := redis.Init(config.C.Redis)
	if err != nil {
		panic(fmt.Sprintf("failed to redis init: %v", err))
	}
	err = dao.Init()
	if err != nil {
		panic(fmt.Sprintf("failed to dao init: %v", err))
	}
}

func main() {
	app, err := GetAppInstance()
	if err != nil {
		panic(err)
	}
	err = app.Start()
	if err != nil {
		panic(err)
	}
	app.WaitQuit()
}
