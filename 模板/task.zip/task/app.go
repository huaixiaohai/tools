package main

import (
	"fmt"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	"mgc-gitlab.mthreads.com/cloud-backend/task/interceptor"

	"mgc-gitlab.mthreads.com/cloud-backend/task/config"

	"google.golang.org/grpc"
	"mgc-gitlab.mthreads.com/cloud-backend/task/pb"
	"mgc-gitlab.mthreads.com/cloud-backend/task/service"

	"mgc-gitlab.mthreads.com/cloud-backend/lib/log"
)

func NewApp(taskSvc *service.TaskSvc,
	taskTypeSvc *service.TaskTypeSvc,
	taskNoteSvc *service.TaskNoteSvc,

	hapsSvc *service.HapsSvc,
) *App {
	return &App{
		taskSvc:     taskSvc,
		taskTypeSvc: taskTypeSvc,
		taskNoteSvc: taskNoteSvc,

		hapsSvc: hapsSvc,
	}
}

type App struct {
	server *grpc.Server

	taskSvc     *service.TaskSvc
	taskTypeSvc *service.TaskTypeSvc
	taskNoteSvc *service.TaskNoteSvc

	hapsSvc *service.HapsSvc
}

func (a *App) registerServer() {
	pb.RegisterTaskSvcServer(a.server, a.taskSvc)
	pb.RegisterTaskTypeSvcServer(a.server, a.taskTypeSvc)
	pb.RegisterTaskNoteSvcServer(a.server, a.taskNoteSvc)
}

func (a *App) chainUnaryInterceptor() grpc.ServerOption {
	return grpc.ChainUnaryInterceptor(interceptor.LoggingInterceptor, interceptor.ServerRecoveryInterceptor)
}

// Start 增加grpc断路器
func (a *App) Start() error {
	var opts = []grpc.ServerOption{
		a.chainUnaryInterceptor(),
	}
	// grpc.ChainUnaryInterceptor(), grpc.ChainStreamInterceptor()
	a.server = grpc.NewServer(opts...)

	a.registerServer()

	go func() {
		lis, err := net.Listen("tcp", config.C.ServerAddress)
		if err != nil {
			panic(fmt.Sprintf("failed to listen: %v", err))
		}
		err = a.server.Serve(lis)
		if err != nil {
			panic(fmt.Sprintf("grpc serve start 失败: %v"))
		}
	}()
	log.Println(config.C.ServerName+" 服务开启, listen: ", config.C.ServerAddress)
	return nil
}

// WaitQuit 等待退出信号退出
func (a *App) WaitQuit() {
	c := make(chan os.Signal, 1)
	signal.Notify(c, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	i := <-c
	log.Println("Received interrupt[%v], shutting down...", i)

	// 收到退出信号后优雅退出，如果无法优雅退出，十秒后强制退出
	select {
	case <-time.After(10 * time.Second):
		a.server.Stop()
		log.Println(config.C.ServerName + "server stop")
		break
	case <-func() chan bool {
		c := make(chan bool, 1)
		go func() {
			a.server.GracefulStop()
			c <- true
		}()
		return c
	}():
		log.Println(config.C.ServerName + "server graceful stop")
		break
	}
}
