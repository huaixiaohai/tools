//go:build wireinject
// +build wireinject

// The build tag makes sure the stub is not built in the final build.

package main

import (
	"github.com/google/wire"
	"mgc-gitlab.mthreads.com/cloud-backend/task/dao"
	"mgc-gitlab.mthreads.com/cloud-backend/task/service"
)

// BuildInjector 生成注入器
func GetAppInstance() (*App, error) {
	wire.Build(
		NewApp,
		service.Set,
		dao.Set,
	)
	return &App{}, nil
}
