package errors

import (
	"fmt"
)

func New(code int, msg string) *err {
	return &err{
		Code:    code,
		Message: msg,
	}
}

func New500(msg string) *err {
	return New(500, msg)
}

func New400(msg string) *err {
	return New(400, msg)
}

type err struct {
	Code    int
	Message string
}

func (a *err) Error() string {
	return fmt.Sprintf("code: %d, message: %s", a.Code, a.Message)
}

var (
	NotFound        = New400("资源不存在")
	Unknow          = New500("未知错误")
	SystemException = New500("系统异常")
)

// task
var (
	ErrTaskNotFound = New500("Task记录没有找到")
)
